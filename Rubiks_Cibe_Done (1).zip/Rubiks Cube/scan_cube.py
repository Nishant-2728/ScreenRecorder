import cv2
import numpy as np

# Define HSV color ranges for each cube color
COLOR_RANGES = {
    'W': ((0, 0, 180), (180, 50, 255)),      # White
    'Y': ((20, 100, 100), (35, 255, 255)),   # Yellow
    'R': ((0, 100, 100), (10, 255, 255)),   # Red (low)
    'O1': ((11, 100, 100), (25, 255, 255)),  # Orange (normal)
    'O2': ((170, 100, 100), (180, 255, 255)),# Orange (high H, for your camera)
    'B': ((100, 100, 100), (130, 255, 255)), # Blue
    'G': ((40, 100, 100), (85, 255, 255)),   # Green
}

FACE_NAMES = ['White', 'Yellow', 'Red', 'Orange', 'Blue', 'Green']
COLOR_LETTERS = ['W', 'Y', 'R', 'O', 'B', 'G']
GRID_OFFSETS = [
    (-60, -60), (0, -60), (60, -60),
    (-60, 0),  (0, 0),   (60, 0),
    (-60, 60), (0, 60),  (60, 60)
]

def detect_color(hsv_pixel):
    for color, (lower, upper) in COLOR_RANGES.items():
        lower = np.array(lower, dtype=np.uint8)
        upper = np.array(upper, dtype=np.uint8)
        if color == 'R':
            if cv2.inRange(hsv_pixel.reshape(1, 1, 3), lower, upper).any():
                return 'R'
        elif color in ['O1', 'O2']:
            if cv2.inRange(hsv_pixel.reshape(1, 1, 3), lower, upper).any():
                return 'O'
        elif color not in ['R', 'O1', 'O2']:
            if cv2.inRange(hsv_pixel.reshape(1, 1, 3), lower, upper).any():
                return color
    # Fallback: use H and V to distinguish
    h, s, v = hsv_pixel
    if h < 11:
        return 'R'
    elif 11 <= h < 26:
        return 'O'
    elif h >= 170:
        if v < 200:
            return 'R'
        else:
            return 'O'
    elif 26 <= h < 35:
        return 'Y'
    elif 40 <= h < 85:
        return 'G'
    elif 100 <= h < 130:
        return 'B'
    else:
        return 'W'

def scan_face(frame, center):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    colors = []
    for dx, dy in GRID_OFFSETS:
        x = center[0] + dx
        y = center[1] + dy
        patch = hsv[y-10:y+10, x-10:x+10]
        avg = np.mean(patch.reshape(-1, 3), axis=0)
        color = detect_color(avg.astype(np.uint8))
        colors.append(color)
    return colors

def scan_centers_for_tuning(cap, center):
    print("\n--- Center Color Tuning ---")
    center_hsvs = []
    center_colors = []
    for face_name in FACE_NAMES:
        print(f"\nAlign the {face_name} center in the grid and press SPACE.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            # Draw center grid
            cv2.rectangle(frame, (center[0]-15, center[1]-15), (center[0]+15, center[1]+15), (0,255,0), 2)
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            patch = hsv[center[1]-10:center[1]+10, center[0]-10:center[0]+10]
            avg = np.mean(patch.reshape(-1, 3), axis=0)
            detected = detect_color(avg.astype(np.uint8))
            print(f"\r{face_name} center HSV: {avg.astype(int)} Detected: {detected}", end="")
            cv2.putText(frame, f'Align {face_name} center and press SPACE', (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
            cv2.imshow('Scan Rubik\'s Cube', frame)
            key = cv2.waitKey(1)
            if key == 27:
                cv2.destroyAllWindows()
                return None, None
            if key == 32:  # SPACE
                center_hsvs.append(avg)
                center_colors.append(detected)
                print()  # Newline
                break
    print("\nSummary of center colors:")
    for i, face_name in enumerate(FACE_NAMES):
        print(f"{face_name:7}: HSV {center_hsvs[i].astype(int)} Detected: {center_colors[i]}")
    return center_hsvs, center_colors

def calibrate_centers_simple(cap, center):
    print("\n--- Calibration: Scan Center of Each Face ---")
    center_hsvs = []
    for face_name in FACE_NAMES:
        print(f"\nAlign the {face_name} center in the grid and press SPACE.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            # Draw center grid
            cv2.rectangle(frame, (center[0]-15, center[1]-15), (center[0]+15, center[1]+15), (0,255,0), 2)
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            patch = hsv[center[1]-10:center[1]+10, center[0]-10:center[0]+10]
            avg = np.mean(patch.reshape(-1, 3), axis=0)
            print(f"\r{face_name} center HSV: {avg.astype(int)} (SPACE=confirm)", end="")
            cv2.putText(frame, f'Align {face_name} center and press SPACE', (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
            cv2.imshow('Calibration', frame)
            key = cv2.waitKey(1)
            if key == 27:
                cv2.destroyAllWindows()
                return None
            if key == 32:  # SPACE
                center_hsvs.append(avg)
                print()  # Newline
                break
    cv2.destroyAllWindows()
    print("\nCalibration summary:")
    for i, face_name in enumerate(FACE_NAMES):
        print(f"{face_name:7}: HSV {center_hsvs[i].astype(int)}")
    return np.array(center_hsvs)

def calibrate_centers_avg(cap, center, num_samples=5):
    print("\n--- Calibration: Scan Center of Each Face (average of 5 samples) ---")
    center_hsvs = []
    for face_name in FACE_NAMES:
        print(f"\nAlign the {face_name} center in the grid.")
        print(f"Press SPACE {num_samples} times to sample, then the average will be used.")
        samples = []
        count = 0
        while count < num_samples:
            ret, frame = cap.read()
            if not ret:
                continue
            # Draw center grid
            cv2.rectangle(frame, (center[0]-15, center[1]-15), (center[0]+15, center[1]+15), (0,255,0), 2)
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            patch = hsv[center[1]-10:center[1]+10, center[0]-10:center[0]+10]
            avg = np.mean(patch.reshape(-1, 3), axis=0)
            print(f"\r{face_name} center HSV: {avg.astype(int)} (SPACE to sample, {num_samples-count} left)", end="")
            cv2.putText(frame, f'Align {face_name} center and press SPACE', (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
            cv2.imshow('Calibration', frame)
            key = cv2.waitKey(1)
            if key == 27:
                cv2.destroyAllWindows()
                return None
            if key == 32:  # SPACE
                samples.append(avg)
                count += 1
                print(f"\nSampled: {avg.astype(int)}")
        mean_hsv = np.mean(samples, axis=0)
        center_hsvs.append(mean_hsv)
        print(f"Averaged HSV for {face_name}: {mean_hsv.astype(int)}")
    cv2.destroyAllWindows()
    print("\nCalibration summary:")
    for i, face_name in enumerate(FACE_NAMES):
        print(f"{face_name:7}: HSV {center_hsvs[i].astype(int)}")
    return np.array(center_hsvs)


def closest_center_color(hsv_pixel, center_hsvs):
    # Compute Euclidean distance in HSV space
    dists = np.linalg.norm(center_hsvs - hsv_pixel, axis=1)
    idx = np.argmin(dists)
    return COLOR_LETTERS[idx]

def scan_face_with_centers(frame, center, center_hsvs):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    colors = []
    for dx, dy in GRID_OFFSETS:
        x = center[0] + dx
        y = center[1] + dy
        patch = hsv[y-10:y+10, x-10:x+10]
        avg = np.mean(patch.reshape(-1, 3), axis=0)
        color = closest_center_color(avg, center_hsvs)
        colors.append(color)
    return colors

def main():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print('Camera not found!')
        return
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    center = (width // 2, height // 2)

    # Calibration: scan center of each face (average of 5 samples per color)
    center_hsvs = calibrate_centers_avg(cap, center, num_samples=5)
    print("\nProceeding to scan all 6 faces...")

    cube_state = []
    for face_idx, face_name in enumerate(FACE_NAMES):
        print(f"\nAlign the {face_name} face in the grid and press SPACE.")
        while True:
            ret, frame = cap.read()
            if not ret:
                continue
            # Draw 3x3 grid
            for dx, dy in GRID_OFFSETS:
                x = center[0] + dx
                y = center[1] + dy
                cv2.rectangle(frame, (x-15, y-15), (x+15, y+15), (0,255,0), 2)
            cv2.putText(frame, f'Align {face_name} face and press SPACE', (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,0,0), 2)
            cv2.imshow('Scan Rubik\'s Cube', frame)
            key = cv2.waitKey(1)
            if key == 27:
                cap.release()
                cv2.destroyAllWindows()
                return
            if key == 32:  # SPACE
                colors = scan_face_with_centers(frame, center, center_hsvs)
                cube_state.extend(colors)
                print(f'\nDetected {face_name} face:')
                for i in range(3):
                    print(' '.join(colors[i*3:(i+1)*3]))
                break
    cap.release()
    cv2.destroyAllWindows()
    # Write the 54-character string to file (no spaces/newlines)
    with open('cube_state.txt', 'w') as f:
        f.write(''.join(cube_state))
    print('\nFull cube state written to cube_state.txt')

if __name__ == '__main__':
    main()