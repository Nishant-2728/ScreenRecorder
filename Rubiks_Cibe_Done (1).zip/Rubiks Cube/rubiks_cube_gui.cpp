#include <SFML/Graphics.hpp>
#include <vector>
#include <array>
#include <string>
#include <ctime>
#include <cstdlib>
#include <tuple>
#include <fstream>
#include <cstdio>
#include <iostream>

// Cube face colors
const sf::Color COLORS[6] = {
    sf::Color::White,    // White
    sf::Color::Yellow,   // Yellow
    sf::Color::Red,      // Red
    sf::Color(255,140,0),// Orange
    sf::Color::Blue,     // Blue
    sf::Color::Green     // Green
};

const char* COLOR_NAMES[6] = {"W", "Y", "R", "O", "B", "G"};

// Face indices
enum { WHITE=0, YELLOW=1, RED=2, ORANGE=3, BLUE=4, GREEN=5 };

// Button struct
struct Button {
    sf::RectangleShape rect;
    sf::Text label;
    std::string action;
};

class Cube {
public:
    // 6 faces, each 3x3
    std::array<std::array<std::array<int, 3>, 3>, 6> faces;
    Cube() { reset(); }
    void reset() {
        for (int f = 0; f < 6; ++f)
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j)
                    faces[f][i][j] = f;
    }
    void scramble() {
        for (int i = 0; i < 30; ++i) {
            int move = rand() % 12;
            doMove(move);
        }
    }
    void setFromString(const std::string& state) {
        if (state.size() != 54) return;
        int idx = 0;
        for (int f = 0; f < 6; ++f)
            for (int i = 0; i < 3; ++i)
                for (int j = 0; j < 3; ++j, ++idx) {
                    char c = state[idx];
                    for (int k = 0; k < 6; ++k) {
                        if (c == COLOR_NAMES[k][0]) faces[f][i][j] = k;
                    }
                }
    }
    // Set only the first face from a 9-character string (for partial scan)
    void setFirstFaceFromString(const std::string& state) {
        if (state.size() != 9) return;
        for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j)
                faces[WHITE][i][j] = charToColorIndex(state[i*3+j]);
    }
    int charToColorIndex(char c) {
        for (int k = 0; k < 6; ++k) {
            if (c == COLOR_NAMES[k][0]) return k;
        }
        return 0; // fallback to white
    }
    // Move mapping: 0=F,1=F',2=R,3=R',4=U,5=U',6=B,7=B',8=L,9=L',10=D,11=D'
    void doMove(int move) {
        switch(move) {
            case 0: rotateFace(WHITE, true);  rotateF(); break;
            case 1: rotateFace(WHITE, false); rotateF(); rotateF(); rotateF(); break;
            case 2: rotateFace(GREEN, true);  rotateR(); break;
            case 3: rotateFace(GREEN, false); rotateR(); rotateR(); rotateR(); break;
            case 4: rotateFace(RED, true);    rotateU(); break;
            case 5: rotateFace(RED, false);   rotateU(); rotateU(); rotateU(); break;
            case 6: rotateFace(YELLOW, true); rotateB(); break;
            case 7: rotateFace(YELLOW, false);rotateB(); rotateB(); rotateB(); break;
            case 8: rotateFace(BLUE, true);   rotateL(); break;
            case 9: rotateFace(BLUE, false);  rotateL(); rotateL(); rotateL(); break;
            case 10:rotateFace(ORANGE, true); rotateD(); break;
            case 11:rotateFace(ORANGE, false);rotateD(); rotateD(); rotateD(); break;
        }
    }
private:
    void rotateFace(int f, bool cw) {
        auto& m = faces[f];
        std::array<std::array<int,3>,3> t = m;
        if (cw) {
            for (int i=0; i<3; ++i) for (int j=0; j<3; ++j) m[j][2-i] = t[i][j];
        } else {
            for (int i=0; i<3; ++i) for (int j=0; j<3; ++j) m[2-j][i] = t[i][j];
        }
    }
    // The following functions rotate the side stickers for each move
    void rotateF() {
        // F: White face
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[RED][2][i];
        for (int i=0; i<3; ++i) faces[RED][2][i]=faces[BLUE][2-i][2];
        for (int i=0; i<3; ++i) faces[BLUE][i][2]=faces[ORANGE][0][2-i];
        for (int i=0; i<3; ++i) faces[ORANGE][0][i]=faces[GREEN][i][0];
        for (int i=0; i<3; ++i) faces[GREEN][i][0]=t[i];
    }
    void rotateR() {
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[RED][i][2];
        for (int i=0; i<3; ++i) faces[RED][i][2]=faces[WHITE][i][2];
        for (int i=0; i<3; ++i) faces[WHITE][i][2]=faces[YELLOW][2-i][0];
        for (int i=0; i<3; ++i) faces[YELLOW][i][0]=faces[ORANGE][2-i][2];
        for (int i=0; i<3; ++i) faces[ORANGE][i][2]=t[i];
    }
    void rotateU() {
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[WHITE][0][i];
        for (int i=0; i<3; ++i) faces[WHITE][0][i]=faces[GREEN][0][i];
        for (int i=0; i<3; ++i) faces[GREEN][0][i]=faces[YELLOW][0][i];
        for (int i=0; i<3; ++i) faces[YELLOW][0][i]=faces[BLUE][0][i];
        for (int i=0; i<3; ++i) faces[BLUE][0][i]=t[i];
    }
    void rotateB() {
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[RED][0][i];
        for (int i=0; i<3; ++i) faces[RED][0][i]=faces[GREEN][2-i][2];
        for (int i=0; i<3; ++i) faces[GREEN][i][2]=faces[ORANGE][2][2-i];
        for (int i=0; i<3; ++i) faces[ORANGE][2][i]=faces[BLUE][i][0];
        for (int i=0; i<3; ++i) faces[BLUE][i][0]=t[i];
    }
    void rotateL() {
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[RED][i][0];
        for (int i=0; i<3; ++i) faces[RED][i][0]=faces[ORANGE][i][0];
        for (int i=0; i<3; ++i) faces[ORANGE][i][0]=faces[YELLOW][2-i][2];
        for (int i=0; i<3; ++i) faces[YELLOW][i][2]=faces[WHITE][2-i][0];
        for (int i=0; i<3; ++i) faces[WHITE][i][0]=t[i];
    }
    void rotateD() {
        int t[3];
        for (int i=0; i<3; ++i) t[i]=faces[WHITE][2][i];
        for (int i=0; i<3; ++i) faces[WHITE][2][i]=faces[BLUE][2][i];
        for (int i=0; i<3; ++i) faces[BLUE][2][i]=faces[YELLOW][2][i];
        for (int i=0; i<3; ++i) faces[YELLOW][2][i]=faces[GREEN][2][i];
        for (int i=0; i<3; ++i) faces[GREEN][2][i]=t[i];
    }
};

// Button creation helper
Button makeButton(const sf::Font& font, const std::string& label, float x, float y, float w, float h, const std::string& action) {
    Button btn;
    btn.rect.setPosition(x, y);
    btn.rect.setSize({w, h});
    btn.rect.setFillColor(sf::Color(70, 120, 200));
    btn.rect.setOutlineColor(sf::Color::Black);
    btn.rect.setOutlineThickness(2);
    btn.label.setFont(font);
    btn.label.setString(label);
    btn.label.setCharacterSize(22);
    btn.label.setFillColor(sf::Color::White);
    sf::FloatRect textRect = btn.label.getLocalBounds();
    btn.label.setOrigin(textRect.left + textRect.width/2, textRect.top + textRect.height/2);
    btn.label.setPosition(x + w/2, y + h/2);
    btn.action = action;
    return btn;
}

int main() {
    srand((unsigned)time(0));
    sf::RenderWindow window(sf::VideoMode(900, 750), "2D Rubik's Cube Simulator");
    window.setFramerateLimit(60);

    // Load font
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        // Try a fallback
        if (!font.loadFromFile("C:/Windows/Fonts/arial.ttf")) {
            return 1;
        }
    }

    // Cube net layout (cross)
    // Each face is 3x3 squares, each square is 40x40 px
    const int S = 40;
    const int ox = 220, oy = 100; // Centered horizontally for larger window
    // Face positions: {face, x, y}
    std::vector<std::tuple<int,int,int>> facePos = {
        {WHITE, 3, 0}, // Top
        {ORANGE, 0, 3}, // Left
        {GREEN, 3, 3}, // Center
        {RED, 6, 3}, // Right
        {BLUE, 9, 3}, // Far right
        {YELLOW, 3, 6} // Bottom
    };

    bool showSolverOptions = false;
    // Buttons
    std::vector<Button> buttons;
    std::vector<Button> solverButtons;
    std::vector<std::string> moveLabels = {"F","F'","R","R'","U","U'","B","B'","L","L'","D","D'"};
    for (int i=0; i<6; ++i) {
        buttons.push_back(makeButton(font, moveLabels[2*i],   240+70*i, 600, 60, 40, moveLabels[2*i]));
        buttons.push_back(makeButton(font, moveLabels[2*i+1], 240+70*i, 650, 60, 40, moveLabels[2*i+1]));
    }
    // Right-side control buttons, spaced vertically
    int rightX = 750, rightY = 100, btnW = 120, btnH = 45, btnGap = 20;
    buttons.push_back(makeButton(font, "Scramble", rightX, rightY, btnW, btnH, "SCRAMBLE"));
    buttons.push_back(makeButton(font, "Reset",    rightX, rightY+btnH+btnGap, btnW, btnH, "RESET"));
    buttons.push_back(makeButton(font, "Scan",     rightX, rightY+2*(btnH+btnGap), btnW, btnH, "SCAN"));
    buttons.push_back(makeButton(font, "Solve",    rightX, rightY+3*(btnH+btnGap), btnW, btnH, "SOLVE"));
    // Solver option buttons (hidden by default), smaller and different color
    int solverBtnW = 100, solverBtnH = 32, solverBtnGap = 12;
    int solverStartY = rightY+4*(btnH+btnGap)+10;
    auto makeSolverButton = [&](const std::string& label, int y, const std::string& action) {
        Button btn = makeButton(font, label, rightX+10, y, solverBtnW, solverBtnH, action);
        btn.rect.setFillColor(sf::Color(120, 180, 80)); // Greenish color
        btn.label.setCharacterSize(12); // Smaller font size
        sf::FloatRect textRect = btn.label.getLocalBounds();
        btn.label.setOrigin(textRect.left + textRect.width/2, textRect.top + textRect.height/2);
        btn.label.setPosition(btn.rect.getPosition().x + solverBtnW/2, btn.rect.getPosition().y + solverBtnH/2);
        return btn;
    };
    solverButtons.push_back(makeSolverButton("DFS Solver",   solverStartY, "DFS_SOLVE"));
    solverButtons.push_back(makeSolverButton("BFS Solver",   solverStartY+solverBtnH+solverBtnGap, "BFS_SOLVE"));
    solverButtons.push_back(makeSolverButton("IDDFS Solver", solverStartY+2*(solverBtnH+solverBtnGap), "IDDFS_SOLVE"));
    solverButtons.push_back(makeSolverButton("IDA* Solver",  solverStartY+3*(solverBtnH+solverBtnGap), "IDASTAR_SOLVE"));

    Cube cube;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::MouseButtonPressed && event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2f mouse(event.mouseButton.x, event.mouseButton.y);
                for (auto& btn : buttons) {
                    if (btn.rect.getGlobalBounds().contains(mouse)) {
                        if (btn.action == "SCRAMBLE") cube.scramble();
                        else if (btn.action == "RESET") cube.reset();
                        else if (btn.action == "SCAN") {
                            std::system("python scan_cube.py");
                            std::ifstream fin("cube_state.txt");
                            std::string state;
                            if (fin) {
                                std::getline(fin, state);
                                if (state.size() == 54) {
                                    cube.setFromString(state);
                                    std::cout << "Cube updated from scan.\n";
                                } else {
                                    std::cout << "Scan failed or incomplete.\n";
                                }
                            } else {
                                std::cout << "Could not open cube_state.txt.\n";
                            }
                        }
                        else if (btn.action == "SOLVE") showSolverOptions = !showSolverOptions;
                        else {
                            for (int i=0; i<12; ++i) if (btn.action == moveLabels[i]) cube.doMove(i);
                        }
                    }
                }
                if (showSolverOptions) {
                    for (auto& btn : solverButtons) {
                        if (btn.rect.getGlobalBounds().contains(mouse)) {
                            if (btn.action == "DFS_SOLVE")   { puts("DFS Solver selected"); }
                            if (btn.action == "BFS_SOLVE")   { puts("BFS Solver selected"); }
                            if (btn.action == "IDDFS_SOLVE") { puts("IDDFS Solver selected"); }
                            if (btn.action == "IDASTAR_SOLVE") { puts("IDA* Solver selected"); }
                        }
                    }
                }
            }
        }
        window.clear(sf::Color(230,230,255));

        // Draw cube net
        for (size_t idx = 0; idx < facePos.size(); ++idx) {
            int face, fx, fy;
            std::tie(face, fx, fy) = facePos[idx];
            for (int i=0; i<3; ++i) for (int j=0; j<3; ++j) {
                sf::RectangleShape sq({(float)S-2, (float)S-2});
                sq.setPosition(ox+S*fx+S*j, oy+S*fy+S*i);
                sq.setFillColor(COLORS[cube.faces[face][i][j]]);
                sq.setOutlineColor(sf::Color::Black);
                sq.setOutlineThickness(2);
                window.draw(sq);
            }
            sf::Text t(COLOR_NAMES[face], font, 18);
            t.setFillColor(sf::Color::Black);
            t.setOrigin(t.getLocalBounds().width/2, 0);
            t.setPosition(ox + S*fx + 1.5*S, oy + S*fy - 22);
            window.draw(t);
        }

        // Draw buttons
        for (auto& btn : buttons) {
            window.draw(btn.rect);
            window.draw(btn.label);
        }
        if (showSolverOptions) {
            for (auto& btn : solverButtons) {
                window.draw(btn.rect);
                window.draw(btn.label);
            }
        }

        sf::Text title("2D Rubik's Cube Simulator", font, 28);
        title.setFillColor(sf::Color(30,60,160));
        title.setPosition(160, 30);
        window.draw(title);

        window.display();
    }
    return 0;
} 